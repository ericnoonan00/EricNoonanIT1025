print('hello')
print('what is your name?')
name = input()
print('hello ' + name)
print('your name is ' + str(int(len(name))) + ' letters long')

print('how old are you?')
age = input()
print('you will be ' + str(int(age) + 1) + ' in a year')
